

/*---------------------------------------------------
 * final assignment for system software
 * created by Jincheng Ma 
 * R0650257
 *--------------------------------------------------*/


/*---------------------------------------------------------------------------------
 *      main file for the sensor_gateway
 *      using code : connmgr.c       datamgr.c       sensor_db.c         sbuffer.c
 *      two shared library: dplist.so           tcpsock.so
 *      two processes, three threads in the main process
 *      one shared buffer for sensor datamgr
 * -------------------------------------------------------------------------------*/


#define _GNU_SOURCE
#include <sqlite3.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <errno.h>
#include <pthread.h>
#include <time.h>
#include <string.h>
#include <signal.h>
#include "lib/dplist.h"
#include "lib/tcpsock.h"
#include "connmgr.h"
#include "sensor_db.h"
#include "datamgr.h"
#include "sbuffer.h"
#include "errmacros.h"

#define FIFO_NAME "logFifo"             
#define EXIT_FAILURE_FORK  -1
#define MAX_SIZE      200
#define LOG_FILE_NAME  "gateway.log"
#define DEFAULT_PORT    1234
/*********************************
 * global variables              *
 *********************************/
    int sequence_number=0;  /*used to track the sequence_number of the log file*/
    sbuffer_t * sbuffer;    /*shared buffer: used to store the sensor data     */
    int result;   
    char *str_result;       /*used to check if log process really read something from logFifo*/
    char recv_buf[MAX_SIZE]; /*buffer used in fifo_reader*/
    char send_buf[MAX_SIZE];/*buffer used in fifo_writer*/
    pid_t child_pid;        /* the track the pid of the child process*/
    int port=DEFAULT_PORT;  /*DEFAULT_PORT if no port was specified from terminal*/
    int data_ready=0;       /*flag set indicating data is already in sbuffer to wake up thread of datamgr, sensor_db*/
    int end_program=0;      /*when timout reaches, this flag set to 1 and program terminates*/
    volatile  pid_t log_pid;          /*pid of log process used to send signal from main process*/
    DBCONN * connection;
    pthread_mutex_t log_mutex=PTHREAD_MUTEX_INITIALIZER;/*used for write to fifo*/
    pthread_mutex_t clean_mutex=PTHREAD_MUTEX_INITIALIZER;
    pthread_t thread_datamgr, thread_sensor_db,thread_connmgr;/*three threads to run on the main process*/
    FILE *fp_log,*fp_fifo_r, *fp_fifo_w;
    int thread_end=0;
    int num_thread_exited=0;

/*********************************
 * functions used                *
 *********************************/

/*used by log process when woken up by main process*/
int read_from_fifo();

/*to be used by connmgr.c sensor_db.c datamgr.c */
void write_to_fifo(char *logmsg);

/*To be used by log process handle the signal from main process */
void signal_handler(int sig);

/*
 * run the thread to manage the connmgr.c code
 * when there is sensor data ready to write
 */
void * run_connmgr();

/*
 * run the thread to manage the datamgr.c code
 * when there is sensor data ready to write
 */
void * run_datamgr();

/*
 * run the thread to manage the sensor_db.c code
 * when there is sensor data ready to write
 */
void * run_sensor_db();

/*clean up the threads when timout is reached in the connmgr*/
void thread_cleanup();


void exit_thread()
{
    thread_end=1;
    notify_thread();
}

int read_from_fifo()
{
    fp_fifo_r = fopen(FIFO_NAME, "r"); 
    printf("syncing with writer ok\n");
    FILE_OPEN_ERROR(fp_fifo_r);
    int bytes=0;
    fp_log=fopen(LOG_FILE_NAME,"a");
  do 
   {
    // fgets : return recv_buf on SUCCESS, return NULL On Failure
    str_result = fgets(recv_buf, MAX_SIZE, fp_fifo_r);
    bytes=sizeof(str_result);
    if ( str_result != NULL )
    { char *log;
        sequence_number++;
        printf("sequence_number is %d\n",sequence_number);
      asprintf(&log,"%d %s\n", sequence_number,recv_buf); 
      printf ("%s\n",recv_buf);
      printf(" %s\n",log);
      if(fp_log!=NULL)
      {
          fwrite(log,strlen(log),1,fp_log);
          //fprintf(fp_log, "%s",recv_buf);
      }
     if(log!=NULL)free(log);
    
    }
  } while ( str_result != NULL ); 
  fclose(fp_log);
  //result = fclose( fp_fifo_r );
  //FILE_CLOSE_ERROR(result);
  return bytes;
}

/*to be used by connmgr.c sensor_db.c datamgr.c */
void write_to_fifo(char *logmsg)
{
    pthread_mutex_lock(&log_mutex);
    printf("enter write_to_fifo function\n");
    kill(log_pid,SIGUSR1);
    char * send_buf;
    fp_fifo_w = fopen(FIFO_NAME, "w"); 
    asprintf(&send_buf,"%s",logmsg);
    fputs( send_buf, fp_fifo_w );
    /*
    if ( fputs( send_buf, fp ) == EOF )
    {
      fprintf( stderr, "Error writing data to fifo\n");
      exit( EXIT_FAILURE );
    } */
    FFLUSH_ERROR(fflush(fp_fifo_w));
    //printf("Message send: %s", send_buf); 
    if(send_buf!=NULL)free( send_buf );
    fclose(fp_fifo_w);
    pthread_mutex_unlock(&log_mutex);
}


/*To be used by log process */
void signal_handler(int sig)
{
    if(sig==SIGUSR1)
    {
        printf("waking up, start to read from fifo\n");
        read_from_fifo();
    }
}

/*---------------------------------------------------------------------------------*/
void pthread_err_handler( int err_code, char *msg, char *file_name, char line_nr )
{
	if ( 0 != err_code )
	{
		fprintf( stderr, "\n%s failed with error code %d in file %s at line %d\n", msg, err_code, file_name, line_nr );		
	}
}

/*
 * run the thread to manage the connmgr.c code
 * when there is sensor data ready to write
 */
void * run_connmgr( )
{
        printf("this is connmgr thread id= %lu\n",pthread_self());
        connmgr_listen(port,&sbuffer);
        fprintf(stderr,"timeout reached,cleaning up and exiting\n ");
        printf("start to clean\n");
        fflush(stdout);
        connmgr_free();
        if(num_thread_exited<2)
         {
            printf("waiting for thread to exit\n");
            notify_thread();
        }
        
        return (void *)0;
}


/*
 * run the thread to manage the datamgr.c code
 * when there is sensor data ready to write
 */
void * run_datamgr()
{
    printf("this is datamgr thread id= %lu\n",pthread_self());
    //printf("sensor db wakes up\n ");
    FILE *fp_sensor_map=fopen("room_sensor.map","r");
    if(fp_sensor_map!=NULL)printf("open room sensor map\n");
    
    while(thread_end==0)
    {
        datamgr_parse_sensor_data(fp_sensor_map,&sbuffer);
//         sleep(1);/*forced context switch*/
    }
    fclose(fp_sensor_map);
    pthread_mutex_lock(&log_mutex);
    num_thread_exited++;
    printf("exited from thread_datamgr %d\n",num_thread_exited);
    pthread_mutex_unlock(&log_mutex);
   
    fflush(stdout);
    
    
    return (void*)0;
}
/*
 * run the thread to manage the sensor_db.c code
 * when there is sensor data ready to write
 */
void * run_sensor_db(void *id)
{
        printf("this is sensor_db thread id= %lu\n",pthread_self());
        
        while(thread_end==0)
        {
            storagemgr_parse_sensor_data(connection, &sbuffer);
//             sleep(1);/*forced context switch allow other thread to read*/
        }
        pthread_mutex_lock(&log_mutex);
        num_thread_exited++;
        printf("exited from thread_sensor_db %d\n",num_thread_exited);
        pthread_mutex_unlock(&log_mutex);
       
    
    return (void *)0;
}


void  thread_cleanup()
{
     disconnect(connection);/*close database connection*/
     pthread_detach(thread_sensor_db);
     datamgr_free();                        /*free the list */
     pthread_detach(thread_sensor_db);

     
}

int main(int argc, char *argv[])
{
    if(argc>1)
    {
        port=atoi(argv[1]);
    }
    
    /* Create the FIFO if it does not exist */ 
    result = mkfifo(FIFO_NAME, 0666);
    CHECK_MKFIFO(result); 
    //create process
    child_pid=fork();
    
    if(child_pid<0)
    {
        fprintf(stderr,"error occured when fork()\n");
        exit (EXIT_FAILURE_FORK);
    } else if(child_pid==0) //if fork succeeded and this is child process
    {
       printf("this is child process with pid= %d, waiting for signal to wake up \n",getpid());
       fp_log=fopen(LOG_FILE_NAME,"w");
       if(fp_log!=NULL)printf("log file open\n");
       signal(SIGUSR1,signal_handler);
       while (1)
           sleep(1);
    } else
    {
        log_pid=child_pid;
        printf("this is main process with pid= %d, starts to make threads \n",getpid());
        //printf("this is my child process with pid= %d, starts to make threads \n",log_pid);
        /*
        int num_trial=0;
        do
        {
            num_trial++;
            connection=init_connection(1);
        }while(connection==NULL&&num_trial<=3);
        
        if(num_trial>3)
        {
            kill(log_pid,SIGTERM);
            return -1;
        }*/
        //kill(log_pid,SIGUSR1);
       
         //printf("hello\n");
         //while(1)sleep(1);
         sleep(1);
         sbuffer_init(& sbuffer);
         connection=init_connection(1);
        
	int id_datamgr, id_sensor_db,id_connmgr;

	id_datamgr = 1;	
        pthread_create( &thread_datamgr, NULL, &run_datamgr, &id_datamgr );
	//presult = pthread_create( &thread_datamgr, NULL, &run_datamgr, &id_datamgr );
	//pthread_err_handler( presult, "pthread_create", __FILE__, __LINE__ );
	
	id_sensor_db = 2;	
        pthread_create( &thread_sensor_db, NULL, &run_sensor_db, &id_sensor_db );
	//presult = pthread_create( &thread_sensor_db, NULL, &run_sensor_db, &id_sensor_db );
	//pthread_err_handler( presult, "pthread_create", __FILE__, __LINE__ );
        
        id_connmgr = 3;	
        pthread_create( &thread_connmgr, NULL, &run_connmgr, &id_connmgr );
	//presult = pthread_create( &thread_connmgr, NULL, &run_connmgr, &id_connmgr );
	//pthread_err_handler( presult, "pthread_create", __FILE__, __LINE__ );
	
	// important: don't forget to join, otherwise main thread exists and destroys the mutex
	pthread_join(thread_datamgr, NULL);
        //presult= pthread_join(thread_datamgr, NULL);
	//pthread_err_handler( presult, "pthread_join", __FILE__, __LINE__ );
       
        pthread_join(thread_sensor_db, NULL);
	//presult= pthread_join(thread_sensor_db, NULL);
	//pthread_err_handler( presult, "pthread_join", __FILE__, __LINE__ );
        
        pthread_join(thread_connmgr, NULL);
        //presult= pthread_join(thread_connmgr, NULL);
	//pthread_err_handler( presult, "pthread_join", __FILE__, __LINE__ );
        //int exit_status;
        sleep(2);
        sbuffer_free(&sbuffer);
        if(fp_fifo_r!=NULL)fclose(fp_fifo_r);
        pthread_mutex_destroy( &log_mutex );
        thread_cleanup();
        kill(log_pid,SIGKILL);
        printf("finish clean\n");
        fflush(stdout);
        printf("hello,after thread \n");
        //waitpid(log_pid, &exit_status,0); 
       

    }
    
    return 0;
}


